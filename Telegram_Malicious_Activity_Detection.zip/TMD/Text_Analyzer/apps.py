from django.apps import AppConfig


class TextAnalyzerConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "Text_Analyzer"
